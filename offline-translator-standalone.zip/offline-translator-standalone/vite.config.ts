import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { fileURLToPath, URL } from "node:url";

// مشروع ثابت 100% (بدون سيرفر) — الناتج في مجلد dist ويُدمج داخل الـ APK عبر Capacitor.
export default defineConfig({
  plugins: [react(), tailwindcss()],
  resolve: {
    alias: { "@": fileURLToPath(new URL("./src", import.meta.url)) },
  },
  worker: { format: "es" },
  build: { chunkSizeWarningLimit: 6000 },
  optimizeDeps: { exclude: ["@huggingface/transformers"] },
});
