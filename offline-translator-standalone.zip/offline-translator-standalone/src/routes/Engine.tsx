import { CheckCircle2, CloudDownload, WifiOff, Cpu } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { useEngine } from "@/lib/translator-context";
import { navigate } from "@/lib/router";
import type { Direction } from "@/lib/useTranslator";

const LABELS: Record<Direction, string> = {
  "ar-en": "عربي ← إنجليزي",
  "en-ar": "إنجليزي ← عربي",
};

export function EngineScreen() {
  const { statuses, progresses, sizes, error, load, online, bundled } = useEngine();
  const anyReady = statuses["ar-en"] === "ready" || statuses["en-ar"] === "ready";

  return (
    <AppShell
      title="محرك الترجمة"
      subtitle={bundled ? "مدمج داخل التطبيق" : "تنزيل لمرة واحدة لكل اتجاه"}
    >
      <div className="space-y-4">
        {(["ar-en", "en-ar"] as Direction[]).map((dir) => {
          const status = statuses[dir];
          const progress = progresses[dir];
          const size = sizes[dir];
          return (
            <div key={dir} className="rounded-3xl border border-border/70 bg-surface p-6 text-center">
              <div className="mx-auto grid size-14 place-items-center rounded-3xl bg-primary/15 text-primary">
                {status === "ready" ? (
                  <CheckCircle2 className="size-7" />
                ) : bundled ? (
                  <Cpu className="size-7" />
                ) : online ? (
                  <CloudDownload className="size-7" />
                ) : (
                  <WifiOff className="size-7" />
                )}
              </div>
              <h2 className="mt-3 text-lg font-bold">{LABELS[dir]}</h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {status === "ready"
                  ? "شغّال داخل جهازك بدون أي إنترنت."
                  : bundled
                    ? "المحرك موجود داخل التطبيق، بيتشغّل تلقائيًا أول ما تفتح شاشة الترجمة."
                    : "يُنزَّل مرة واحدة (~٩٠ ميجابايت) ويُحفظ في جهازك."}
              </p>

              {status === "loading" ? (
                <div className="mt-4">
                  <div className="h-2.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className="h-full rounded-full bg-primary transition-[width] duration-300"
                      style={{ width: `${Math.max(progress, 5)}%` }}
                    />
                  </div>
                  <p className="mt-2 text-xs text-muted-foreground">
                    جارٍ {bundled ? "التجهيز" : "التنزيل والتجهيز"}…
                    {size.total > 0
                      ? ` ${progress}% (${size.loaded.toFixed(1)} من ${size.total.toFixed(1)} م.ب)`
                      : ""}
                  </p>
                </div>
              ) : status === "ready" ? (
                <p className="mt-4 text-sm font-bold text-primary">جاهز ✓</p>
              ) : (
                <button
                  onClick={() => load(dir)}
                  disabled={!bundled && !online}
                  className="mt-4 w-full rounded-2xl bg-accent px-4 py-3.5 text-sm font-bold text-accent-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
                >
                  {bundled
                    ? status === "error"
                      ? "إعادة المحاولة"
                      : "تشغيل المحرك الآن"
                    : online
                      ? "تنزيل هذا المحرك"
                      : "يلزم اتصال لمرة واحدة فقط"}
                </button>
              )}
            </div>
          );
        })}

        {anyReady ? (
          <button
            onClick={() => navigate("/translate")}
            className="w-full rounded-2xl bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground"
          >
            ابدأ الترجمة
          </button>
        ) : null}

        {error ? <p className="text-xs text-destructive">تعذّر التحميل: {error}</p> : null}

        <ul className="space-y-2 rounded-2xl border border-border/70 bg-surface/60 p-4 text-sm text-muted-foreground">
          {bundled ? (
            <li>• النماذج مدمجة داخل الـ APK، فالتطبيق يعمل أوفلاين من أول مرة.</li>
          ) : (
            <li>• التنزيل مرة واحدة فقط لكل اتجاه، ثم يعمل التطبيق أوفلاين بالكامل.</li>
          )}
          <li>• لا تُرسل أي جملة إلى الإنترنت — كل الترجمة داخل جهازك.</li>
          <li>• قبل تجهيز المحرك تتوفر ترجمة الكلمات الشائعة من القاموس المدمج.</li>
        </ul>
      </div>
    </AppShell>
  );
}
