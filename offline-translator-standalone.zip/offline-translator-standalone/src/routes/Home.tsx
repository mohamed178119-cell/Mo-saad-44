import { Languages, HardDriveDownload, ShieldCheck, Smartphone } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { useEngine } from "@/lib/translator-context";

export function HomeScreen() {
  const { bundled, statuses, progresses, error, supported } = useEngine();
  const anyReady = statuses["ar-en"] === "ready" || statuses["en-ar"] === "ready";
  const loading = statuses["ar-en"] === "loading" || statuses["en-ar"] === "loading";
  const progress = Math.max(progresses["ar-en"], progresses["en-ar"]);

  return (
    <AppShell title="ترجمة أوفلاين" subtitle="عربي ↔ إنجليزي · داخل جهازك">
      <div className="space-y-4">
        <section className="rounded-3xl border border-border/70 bg-gradient-to-b from-primary/15 to-surface p-6 text-center">
          <div className="mx-auto grid size-16 place-items-center rounded-3xl bg-primary text-2xl font-extrabold text-primary-foreground">
            ت
          </div>
          <h2 className="mt-4 text-xl font-extrabold">ترجم أي جملة بدون إنترنت</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            محرك ذكاء اصطناعي كامل يعمل داخل جهازك، بدون حساب وبدون إرسال بياناتك لأي خادم.
          </p>
          <a
            href="#/translate"
            className="mt-5 flex items-center justify-center gap-2 rounded-2xl bg-primary px-4 py-3.5 text-sm font-bold text-primary-foreground"
          >
            <Languages className="size-4" /> ابدأ الترجمة
          </a>
          {bundled === false && !anyReady && supported ? (
            <a
              href="#/engine"
              className="mt-2 flex items-center justify-center gap-2 rounded-2xl border border-border px-4 py-3 text-sm font-semibold"
            >
              <HardDriveDownload className="size-4" />
              {loading ? `جارٍ تنزيل المحرك… ${progress}%` : "تنزيل المحرك الذكي"}
            </a>
          ) : null}
          {error ? (
            <p className="mt-3 text-xs leading-relaxed text-destructive">{error}</p>
          ) : null}
        </section>

        <section className="grid grid-cols-2 gap-3">
          <Feature
            icon={<ShieldCheck className="size-5" />}
            title="خصوصية كاملة"
            text="لا تغادر جملك جهازك أبدًا."
          />
          <Feature
            icon={<HardDriveDownload className="size-5" />}
            title={bundled ? "مدمج في التطبيق" : "تنزيل واحد"}
            text={bundled ? "بدون أي تنزيل إضافي." : "~٩٠ م.ب لكل اتجاه ثم أوفلاين دائمًا."}
          />
          <Feature
            icon={<Languages className="size-5" />}
            title="جُمل كاملة"
            text="ترجمة نصوص وليس كلمات فقط."
          />
          <Feature
            icon={<Smartphone className="size-5" />}
            title="تطبيق حقيقي"
            text="يعمل بدون متصفح وبدون موقع."
          />
        </section>
      </div>
    </AppShell>
  );
}

function Feature({ icon, title, text }: { icon: React.ReactNode; title: string; text: string }) {
  return (
    <div className="rounded-2xl border border-border/70 bg-surface p-4">
      <div className="text-primary">{icon}</div>
      <div className="mt-2 text-sm font-bold">{title}</div>
      <p className="mt-1 text-xs text-muted-foreground">{text}</p>
    </div>
  );
}
