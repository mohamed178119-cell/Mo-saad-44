import { useEffect, useRef, useState } from "react";
import { Copy, Volume2, Eraser, ArrowLeftRight } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { useEngine } from "@/lib/translator-context";
import { translateOffline } from "@/lib/packs";
import type { Direction } from "@/lib/useTranslator";

const META: Record<
  Direction,
  {
    sourceLabel: string;
    targetLabel: string;
    placeholder: string;
    sourceDir: "rtl" | "ltr";
    targetDir: "rtl" | "ltr";
    speakLang: string;
  }
> = {
  "ar-en": {
    sourceLabel: "العربية",
    targetLabel: "English",
    placeholder: "اكتب أي جملة بالعربية…",
    sourceDir: "rtl",
    targetDir: "ltr",
    speakLang: "en-US",
  },
  "en-ar": {
    sourceLabel: "English",
    targetLabel: "العربية",
    placeholder: "Type any English sentence…",
    sourceDir: "ltr",
    targetDir: "rtl",
    speakLang: "ar-EG",
  },
};

export function TranslateScreen() {
  const { statuses, translate, load, bundled, error } = useEngine();
  const [dir, setDir] = useState<Direction>("ar-en");
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [busy, setBusy] = useState(false);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);
  const seq = useRef(0);

  const status = statuses[dir];
  const meta = META[dir];

  // النماذج مدمجة داخل التطبيق: نشغّل اتجاه الترجمة الحالي تلقائيًا (واحد فقط لتوفير الذاكرة).
  useEffect(() => {
    if (bundled) load(dir);
  }, [bundled, dir, load]);

  useEffect(() => {
    if (debounce.current) clearTimeout(debounce.current);
    const text = input.trim();
    if (!text) {
      setOutput("");
      return;
    }
    if (status !== "ready") {
      setOutput(translateOffline(text, dir).text);
      return;
    }
    debounce.current = setTimeout(() => {
      const my = ++seq.current;
      setBusy(true);
      translate(text, dir)
        .then((res) => {
          if (my === seq.current) setOutput(res);
        })
        .catch(() => {})
        .finally(() => {
          if (my === seq.current) setBusy(false);
        });
    }, 450);
    return () => {
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [input, status, translate, dir]);

  const swap = () => {
    setDir((d) => (d === "ar-en" ? "en-ar" : "ar-en"));
    setInput(output);
    setOutput("");
  };

  const copy = () => output && navigator.clipboard?.writeText(output).catch(() => {});
  const speak = () => {
    if (!output || !window.speechSynthesis) return;
    const u = new SpeechSynthesisUtterance(output);
    u.lang = meta.speakLang;
    window.speechSynthesis.speak(u);
  };

  return (
    <AppShell title="الترجمة" subtitle={dir === "ar-en" ? "عربي ← إنجليزي" : "إنجليزي ← عربي"}>
      <div className="space-y-3">
        <div className="flex items-center gap-2 rounded-2xl border border-border/70 bg-surface p-2 text-sm font-semibold">
          <span className="grow text-center">{meta.sourceLabel}</span>
          <button
            onClick={swap}
            aria-label="تبديل اتجاه الترجمة"
            className="grid size-9 shrink-0 place-items-center rounded-xl bg-primary/15 text-primary"
          >
            <ArrowLeftRight className="size-4" />
          </button>
          <span className="grow text-center">{meta.targetLabel}</span>
        </div>

        {status === "loading" ? (
          <div className="rounded-2xl border border-accent/40 bg-accent/10 px-4 py-3 text-xs font-semibold text-accent">
            جارٍ تجهيز المحرك الذكي… (بيتم مرة عند أول فتح، ممكن ياخد ثواني)
          </div>
        ) : status === "error" ? (
          <button
            onClick={() => load(dir)}
            className="block w-full rounded-2xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-start text-xs font-semibold text-destructive"
          >
            تعذّر تشغيل المحرك{error ? `: ${error}` : ""} — اضغط لإعادة المحاولة.
          </button>
        ) : status !== "ready" && bundled === false ? (
          <a
            href="#/engine"
            className="block rounded-2xl border border-accent/40 bg-accent/10 px-4 py-3 text-xs font-semibold text-accent"
          >
            تعمل الآن بالقاموس المدمج فقط — اضغط لتنزيل محرك «{meta.sourceLabel} ← {meta.targetLabel}».
          </a>
        ) : null}

        <div className="rounded-2xl border border-border/70 bg-surface p-4" dir={meta.sourceDir}>
          <div className="mb-2 text-xs font-semibold text-muted-foreground">{meta.sourceLabel}</div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={5}
            placeholder={meta.placeholder}
            className="w-full resize-none bg-transparent text-lg outline-none placeholder:text-muted-foreground"
          />
          <div className="mt-2 flex items-center justify-between border-t border-border/60 pt-2 text-xs text-muted-foreground">
            <span>{input.trim() ? input.trim().split(/\s+/).length : 0} كلمة</span>
            <button
              onClick={() => setInput("")}
              className="inline-flex items-center gap-1 hover:text-foreground"
            >
              <Eraser className="size-3.5" /> مسح
            </button>
          </div>
        </div>

        <div className="rounded-2xl border border-primary/30 bg-primary/5 p-4" dir={meta.targetDir}>
          <div className="mb-2 flex items-center justify-between text-xs font-semibold text-muted-foreground">
            <span>{meta.targetLabel}</span>
            {busy ? <span className="text-primary">…</span> : null}
          </div>
          <p className="min-h-16 whitespace-pre-wrap text-lg font-medium leading-relaxed">
            {output || <span className="text-muted-foreground">…</span>}
          </p>
          <div className="mt-3 flex items-center gap-2 border-t border-border/60 pt-3 text-xs">
            <button
              onClick={speak}
              className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-1.5 hover:bg-muted"
            >
              <Volume2 className="size-3.5" /> نطق
            </button>
            <button
              onClick={copy}
              className="inline-flex items-center gap-1 rounded-lg bg-primary px-3 py-1.5 font-semibold text-primary-foreground"
            >
              <Copy className="size-3.5" /> نسخ
            </button>
            <span className="grow" />
            <span className="text-muted-foreground">
              {status === "ready" ? "محرك ذكي · أوفلاين" : "قاموس مدمج"}
            </span>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
