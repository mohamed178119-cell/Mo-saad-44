/// <reference lib="webworker" />
import { pipeline, env } from "@huggingface/transformers";

export type Direction = "ar-en" | "en-ar";

const MODELS: Record<Direction, string> = {
  "ar-en": "Xenova/opus-mt-ar-en",
  "en-ar": "Xenova/opus-mt-en-ar",
};

const ORIGIN = self.location.origin;

/** يجعل ملفات onnxruntime (wasm) تُقرأ من داخل التطبيق بدل الإنترنت. */
function useLocalWasm() {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const wasm = (env as any).backends?.onnx?.wasm;
    if (!wasm) return;
    wasm.proxy = false;
    wasm.numThreads = 1; // أوسع توافق مع كل الهواتف (بدون SharedArrayBuffer)
    const base = `${ORIGIN}/ort/`;
    const cur = wasm.wasmPaths;
    const rebase = (u: unknown) => base + String(u).split("/").pop()!.replace(/\.mjs$/, ".js");
    if (cur && typeof cur === "object") {
      const next: Record<string, string> = {};
      if (cur.mjs) next["mjs"] = rebase(cur.mjs);
      if (cur.wasm) next["wasm"] = String(cur.wasm).startsWith("http") ? base + String(cur.wasm).split("/").pop() : base + String(cur.wasm);
      wasm.wasmPaths = next;
    } else {
      wasm.wasmPaths = base;
    }
  } catch {
    /* ignore */
  }
}

let configured = false;
function configure(local: boolean) {
  if (configured) return;
  configured = true;
  useLocalWasm();
  env.allowLocalModels = local;
  env.allowRemoteModels = !local;
  env.localModelPath = `${ORIGIN}/models/`;
  env.useBrowserCache = !local;
}

let localMode = false;

const translators: Partial<Record<Direction, unknown>> = {};
const loadings: Partial<Record<Direction, Promise<unknown>>> = {};

type FileProgress = { loaded: number; total: number };
const files: Record<Direction, Map<string, FileProgress>> = {
  "ar-en": new Map(),
  "en-ar": new Map(),
};

function postProgress(dir: Direction) {
  let loaded = 0;
  let total = 0;
  for (const f of files[dir].values()) {
    loaded += f.loaded;
    total += f.total;
  }
  const pct = total > 0 ? Math.min(99, Math.round((loaded / total) * 100)) : 0;
  self.postMessage({
    type: "progress",
    dir,
    pct,
    loadedMB: loaded / 1048576,
    totalMB: total / 1048576,
  });
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Translator = (text: string, opts?: Record<string, unknown>) => Promise<any>;

async function getTranslator(dir: Direction): Promise<Translator> {
  const existing = translators[dir] as Translator | undefined;
  if (existing) return existing;
  configure(localMode);
  if (!loadings[dir]) {
    loadings[dir] = pipeline("translation", MODELS[dir], {
      dtype: "q8",
      device: "wasm",
      progress_callback: (p: unknown) => {
        const e = p as { status?: string; file?: string; loaded?: number; total?: number };
        if (e.status === "progress" && e.file) {
          files[dir].set(e.file, { loaded: e.loaded ?? 0, total: e.total ?? 0 });
          postProgress(dir);
        }
      },
    }).catch((err: unknown) => {
      delete loadings[dir]; // يسمح بإعادة المحاولة
      throw err;
    });
  }
  const t = (await loadings[dir]) as Translator;
  translators[dir] = t;
  return t;
}

self.addEventListener("message", async (event: MessageEvent) => {
  const data = event.data as {
    type: string;
    id?: number;
    text?: string;
    dir?: Direction;
    local?: boolean;
  };

  if (data.type === "init") {
    localMode = !!data.local;
    return;
  }

  const dir: Direction = data.dir === "en-ar" ? "en-ar" : "ar-en";

  try {
    if (data.type === "load") {
      await getTranslator(dir);
      self.postMessage({ type: "ready", dir });
      return;
    }

    if (data.type === "translate") {
      const t = await getTranslator(dir);
      const text = (data.text ?? "").trim();
      if (!text) {
        self.postMessage({ type: "result", id: data.id, dir, text: "" });
        return;
      }
      const chunks = text
        .split(/\n+/)
        .map((line) => line.trim())
        .filter(Boolean);
      const out: string[] = [];
      for (const chunk of chunks) {
        const res = (await t(chunk, { max_new_tokens: 512 })) as Array<{ translation_text: string }>;
        out.push(res[0]?.translation_text ?? "");
      }
      self.postMessage({ type: "result", id: data.id, dir, text: out.join("\n") });
    }
  } catch (error) {
    self.postMessage({
      type: "error",
      id: data.id,
      dir,
      message: error instanceof Error ? error.message : String(error),
    });
  }
});
