import type { ReactNode } from "react";
import { Home, Languages, HardDriveDownload } from "lucide-react";
import { useEngine } from "@/lib/translator-context";
import { useRoute, type Route } from "@/lib/router";

const tabs: { to: Route; label: string; icon: typeof Home }[] = [
  { to: "/", label: "الرئيسية", icon: Home },
  { to: "/translate", label: "الترجمة", icon: Languages },
  { to: "/engine", label: "المحرك", icon: HardDriveDownload },
];

export function AppShell({
  title,
  subtitle,
  children,
}: {
  title: string;
  subtitle?: string;
  children: ReactNode;
}) {
  const { online, statuses, bundled } = useEngine();
  const list = [statuses["ar-en"], statuses["en-ar"]];
  const status = list.every((s) => s === "ready")
    ? "ready"
    : list.some((s) => s === "loading")
      ? "loading"
      : list.some((s) => s === "ready")
        ? "partial"
        : "idle";
  const route = useRoute();

  const engineLabel =
    status === "ready" || status === "partial"
      ? "المحرك جاهز"
      : status === "loading"
        ? "جارٍ التجهيز"
        : bundled
          ? "المحرك مدمج"
          : "المحرك غير منزّل";

  return (
    <div dir="rtl" className="flex min-h-[100dvh] flex-col bg-background text-foreground">
      <header className="sticky top-0 z-20 border-b border-border/60 bg-surface/90 backdrop-blur">
        <div className="mx-auto flex max-w-lg items-center justify-between gap-3 px-4 pb-3 pt-[calc(max(env(safe-area-inset-top,0px),var(--safe-area-inset-top,0px))+0.9rem)]">
          <div>
            <h1 className="text-base font-bold leading-tight">{title}</h1>
            {subtitle ? <p className="text-[11px] text-muted-foreground">{subtitle}</p> : null}
          </div>
          <div className="flex items-center gap-2 text-[10px] font-semibold">
            <span
              className={`rounded-full px-2.5 py-1 ${
                status === "ready" || status === "partial"
                  ? "bg-primary/15 text-primary"
                  : "bg-muted text-muted-foreground"
              }`}
            >
              {engineLabel}
            </span>
            <span
              className={`rounded-full px-2.5 py-1 ${
                online ? "bg-accent/15 text-accent" : "bg-primary/15 text-primary"
              }`}
            >
              {online ? "متصل" : "أوفلاين"}
            </span>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-lg grow px-4 py-5">{children}</main>

      <nav className="sticky bottom-0 z-20 border-t border-border/60 bg-surface/95 backdrop-blur">
        <div className="mx-auto flex max-w-lg items-stretch pb-[max(env(safe-area-inset-bottom,0px),var(--safe-area-inset-bottom,0px))]">
          {tabs.map(({ to, label, icon: Icon }) => {
            const active = route === to;
            return (
              <a
                key={to}
                href={`#${to}`}
                className={`flex grow flex-col items-center gap-1 py-2.5 text-[11px] font-semibold transition-colors ${
                  active ? "text-primary" : "text-muted-foreground"
                }`}
              >
                <Icon className={`size-5 ${active ? "" : "opacity-70"}`} />
                {label}
              </a>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
