import { TranslatorProvider } from "@/lib/translator-context";
import { useRoute } from "@/lib/router";
import { HomeScreen } from "@/routes/Home";
import { TranslateScreen } from "@/routes/Translate";
import { EngineScreen } from "@/routes/Engine";

function Screen() {
  const route = useRoute();
  if (route === "/translate") return <TranslateScreen />;
  if (route === "/engine") return <EngineScreen />;
  return <HomeScreen />;
}

export function App() {
  return (
    <TranslatorProvider>
      <Screen />
    </TranslatorProvider>
  );
}
