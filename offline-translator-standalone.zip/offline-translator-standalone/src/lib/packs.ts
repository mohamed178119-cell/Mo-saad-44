export type PackId = "ar-en" | "en-ar" | "ar-fr" | "ar-tr";

export interface LanguagePack {
  id: PackId;
  name: string;
  from: string;
  to: string;
  sizeLabel: string;
  entries: Record<string, string>;
}

const arEnWords: Record<string, string> = {
  "مرحبا": "hello",
  "أهلا": "welcome",
  "السلام عليكم": "peace be upon you",
  "صباح الخير": "good morning",
  "مساء الخير": "good evening",
  "تصبح على خير": "good night",
  "كيف حالك": "how are you",
  "بخير": "fine",
  "شكرا": "thank you",
  "عفوا": "you're welcome",
  "من فضلك": "please",
  "آسف": "sorry",
  "نعم": "yes",
  "لا": "no",
  "ربما": "maybe",
  "اليوم": "today",
  "غدا": "tomorrow",
  "أمس": "yesterday",
  "الآن": "now",
  "دائما": "always",
  "أبدا": "never",
  "ماء": "water",
  "خبز": "bread",
  "طعام": "food",
  "أكل": "eat",
  "شرب": "drink",
  "بيت": "house",
  "مدرسة": "school",
  "جامعة": "university",
  "عمل": "work",
  "كتاب": "book",
  "قلم": "pen",
  "هاتف": "phone",
  "حاسوب": "computer",
  "سيارة": "car",
  "طريق": "road",
  "مدينة": "city",
  "قرية": "village",
  "بلد": "country",
  "سوق": "market",
  "مال": "money",
  "سعر": "price",
  "غالي": "expensive",
  "رخيص": "cheap",
  "كبير": "big",
  "صغير": "small",
  "جميل": "beautiful",
  "جديد": "new",
  "قديم": "old",
  "سريع": "fast",
  "بطيء": "slow",
  "حار": "hot",
  "بارد": "cold",
  "سعيد": "happy",
  "حزين": "sad",
  "متعب": "tired",
  "مريض": "sick",
  "طبيب": "doctor",
  "مستشفى": "hospital",
  "دواء": "medicine",
  "مطار": "airport",
  "فندق": "hotel",
  "مطعم": "restaurant",
  "شارع": "street",
  "يمين": "right",
  "يسار": "left",
  "أمام": "in front",
  "خلف": "behind",
  "أين": "where",
  "متى": "when",
  "لماذا": "why",
  "كيف": "how",
  "كم": "how much",
  "أنا": "I",
  "أنت": "you",
  "هو": "he",
  "هي": "she",
  "نحن": "we",
  "هم": "they",
  "أب": "father",
  "أم": "mother",
  "أخ": "brother",
  "أخت": "sister",
  "ابن": "son",
  "بنت": "daughter",
  "صديق": "friend",
  "حب": "love",
  "وقت": "time",
  "يوم": "day",
  "ليل": "night",
  "شمس": "sun",
  "قمر": "moon",
  "سماء": "sky",
  "بحر": "sea",
  "جبل": "mountain",
  "شجرة": "tree",
  "زهرة": "flower",
  "مطر": "rain",
  "ريح": "wind",
  "نار": "fire",
  "أرض": "earth",
  "لغة": "language",
  "ترجمة": "translation",
  "كلمة": "word",
  "جملة": "sentence",
  "سؤال": "question",
  "جواب": "answer",
  "مساعدة": "help",
  "مهم": "important",
  "ممكن": "possible",
  "صحيح": "correct",
  "خطأ": "wrong",
  "أريد": "I want",
  "أحتاج": "I need",
  "أحب": "I love",
  "أعرف": "I know",
  "أفهم": "I understand",
  "لا أفهم": "I don't understand",
  "تكلم": "speak",
  "اسمع": "listen",
  "انظر": "look",
  "اذهب": "go",
  "تعال": "come",
  "قف": "stop",
  "انتظر": "wait",
  "افتح": "open",
  "أغلق": "close",
  "اسم": "name",
  "ما اسمك": "what is your name",
  "اسمي": "my name is",
  "من أين أنت": "where are you from",
  "مع السلامة": "goodbye",
};

const arFrWords: Record<string, string> = {
  "مرحبا": "bonjour",
  "شكرا": "merci",
  "نعم": "oui",
  "لا": "non",
  "من فضلك": "s'il vous plaît",
  "آسف": "désolé",
  "ماء": "eau",
  "خبز": "pain",
  "بيت": "maison",
  "مدرسة": "école",
  "كتاب": "livre",
  "سيارة": "voiture",
  "صديق": "ami",
  "حب": "amour",
  "اليوم": "aujourd'hui",
  "غدا": "demain",
  "كيف حالك": "comment ça va",
  "مع السلامة": "au revoir",
  "كبير": "grand",
  "صغير": "petit",
  "جميل": "beau",
  "وقت": "temps",
  "مال": "argent",
  "طعام": "nourriture",
  "مساعدة": "aide",
};

const arTrWords: Record<string, string> = {
  "مرحبا": "merhaba",
  "شكرا": "teşekkürler",
  "نعم": "evet",
  "لا": "hayır",
  "من فضلك": "lütfen",
  "آسف": "üzgünüm",
  "ماء": "su",
  "خبز": "ekmek",
  "بيت": "ev",
  "مدرسة": "okul",
  "كتاب": "kitap",
  "سيارة": "araba",
  "صديق": "arkadaş",
  "حب": "aşk",
  "اليوم": "bugün",
  "غدا": "yarın",
  "كيف حالك": "nasılsın",
  "مع السلامة": "hoşça kal",
  "كبير": "büyük",
  "صغير": "küçük",
  "جميل": "güzel",
  "وقت": "zaman",
  "مال": "para",
  "طعام": "yemek",
  "مساعدة": "yardım",
};

function invert(map: Record<string, string>): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(map)) {
    const key = v.toLowerCase();
    if (!(key in out)) out[key] = k;
  }
  return out;
}

export const PACKS: LanguagePack[] = [
  {
    id: "ar-en",
    name: "عربي ← إنجليزي",
    from: "العربية",
    to: "English",
    sizeLabel: "١٫٢ م.ب",
    entries: arEnWords,
  },
  {
    id: "en-ar",
    name: "إنجليزي ← عربي",
    from: "English",
    to: "العربية",
    sizeLabel: "١٫١ م.ب",
    entries: invert(arEnWords),
  },
  {
    id: "ar-fr",
    name: "عربي ← فرنسي",
    from: "العربية",
    to: "Français",
    sizeLabel: "٠٫٨ م.ب",
    entries: arFrWords,
  },
  {
    id: "ar-tr",
    name: "عربي ← تركي",
    from: "العربية",
    to: "Türkçe",
    sizeLabel: "٠٫٧ م.ب",
    entries: arTrWords,
  },
];

export function getPack(id: PackId): LanguagePack {
  return PACKS.find((p) => p.id === id) ?? (PACKS[0] as LanguagePack);
}

const AR_DIACRITICS = /[\u064B-\u0652\u0670]/g;

function normalize(token: string): string {
  return token
    .toLowerCase()
    .replace(AR_DIACRITICS, "")
    .replace(/[إأآ]/g, "ا")
    .replace(/ى/g, "ي")
    .replace(/ة/g, "ه")
    .replace(/[^\p{L}\p{N}']/gu, "");
}

function buildIndex(entries: Record<string, string>) {
  const index = new Map<string, string>();
  for (const [k, v] of Object.entries(entries)) {
    index.set(normalize(k), v);
    index.set(k.toLowerCase(), v);
  }
  return index;
}

const indexCache = new Map<PackId, Map<string, string>>();

function indexFor(pack: LanguagePack) {
  let idx = indexCache.get(pack.id);
  if (!idx) {
    idx = buildIndex(pack.entries);
    indexCache.set(pack.id, idx);
  }
  return idx;
}

export interface TranslationResult {
  text: string;
  total: number;
  matched: number;
  unknown: string[];
}

/** Offline translation: longest-phrase-first matching over the local pack. */
export function translateOffline(input: string, packId: PackId): TranslationResult {
  const pack = getPack(packId);
  const idx = indexFor(pack);
  const lines = input.split(/\n/);
  const unknown: string[] = [];
  let total = 0;
  let matched = 0;

  const outLines = lines.map((line) => {
    const tokens = line.split(/(\s+)/);
    const words = tokens.filter((t) => t.trim().length > 0);
    const out: string[] = [];
    let i = 0;
    while (i < words.length) {
      let hit: string | undefined;
      let span = 0;
      for (let n = Math.min(4, words.length - i); n >= 1; n--) {
        const phrase = words.slice(i, i + n).join(" ");
        const clean = phrase.replace(/[.,!?؟،؛:]+$/u, "");
        const found = idx.get(normalize(clean)) ?? idx.get(clean.toLowerCase());
        if (found) {
          hit = found + phrase.slice(clean.length);
          span = n;
          break;
        }
      }
      total += 1;
      if (hit) {
        matched += 1;
        out.push(hit);
        i += span;
      } else {
        const w = words[i] as string;
        out.push(w);
        unknown.push(w);
        i += 1;
      }
    }
    return out.join(" ");
  });

  return { text: outLines.join("\n"), total, matched, unknown };
}
