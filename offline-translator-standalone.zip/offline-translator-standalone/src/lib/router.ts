import { useEffect, useState } from "react";

export type Route = "/" | "/translate" | "/engine";

function read(): Route {
  const h = window.location.hash.replace(/^#/, "");
  return h === "/translate" || h === "/engine" ? h : "/";
}

export function useRoute(): Route {
  const [route, setRoute] = useState<Route>(read);
  useEffect(() => {
    const on = () => setRoute(read());
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return route;
}

export function navigate(to: Route) {
  window.location.hash = to;
}
