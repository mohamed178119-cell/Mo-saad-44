import { useCallback, useEffect, useRef, useState } from "react";

export type EngineStatus = "idle" | "loading" | "ready" | "error";
export type Direction = "ar-en" | "en-ar";

const DIRECTIONS: Direction[] = ["ar-en", "en-ar"];
const READY_KEY = (dir: Direction) => `tarjama.engine.installed.${dir}`;

type ByDir<T> = Record<Direction, T>;
const init = <T,>(value: T): ByDir<T> => ({ "ar-en": value, "en-ar": value });

/** هل النماذج مدمجة داخل التطبيق؟ (الـ workflow يضع public/models/manifest.json) */
async function detectBundled(): Promise<boolean> {
  try {
    const r = await fetch("/models/manifest.json", { cache: "no-store" });
    if (!r.ok) return false;
    const j = (await r.json()) as { models?: unknown };
    return Array.isArray(j.models) && j.models.length > 0;
  } catch {
    return false;
  }
}

export function useTranslator() {
  const workerRef = useRef<Worker | null>(null);
  const idRef = useRef(0);
  const pending = useRef(new Map<number, (value: string) => void>());
  const rejecters = useRef(new Map<number, (reason: Error) => void>());
  const modeRef = useRef<Promise<boolean> | null>(null);

  const [statuses, setStatuses] = useState<ByDir<EngineStatus>>(init<EngineStatus>("idle"));
  const [progresses, setProgresses] = useState<ByDir<number>>(init(0));
  const [sizes, setSizes] = useState<ByDir<{ loaded: number; total: number }>>(
    init({ loaded: 0, total: 0 }),
  );
  const [error, setError] = useState<string | null>(null);
  const [installedBefore, setInstalledBefore] = useState<ByDir<boolean>>(init(false));
  const [bundled, setBundled] = useState<boolean | null>(null);
  const [supported, setSupported] = useState(true);

  useEffect(() => {
    try {
      setInstalledBefore({
        "ar-en": localStorage.getItem(READY_KEY("ar-en")) === "1",
        "en-ar": localStorage.getItem(READY_KEY("en-ar")) === "1",
      });
    } catch {
      /* ignore */
    }

    if (typeof Worker === "undefined" || typeof WebAssembly === "undefined") {
      setSupported(false);
      setError("هذا الهاتف لا يدعم تشغيل المحرك. حدّث تطبيق Android System WebView من متجر Play.");
      return;
    }

    let worker: Worker;
    try {
      worker = new Worker(new URL("../workers/translator.worker.ts", import.meta.url), {
        type: "module",
      });
    } catch {
      setSupported(false);
      setError("تعذّر تشغيل المحرك على هذا الهاتف. حدّث تطبيق Android System WebView من متجر Play.");
      return;
    }
    workerRef.current = worker;

    const mode = detectBundled();
    modeRef.current = mode;
    mode.then((local) => {
      setBundled(local);
      worker.postMessage({ type: "init", local });
    });

    worker.onerror = (e) => {
      setError(e.message || "حدث خطأ في المحرك");
      setStatuses((s) => ({
        "ar-en": s["ar-en"] === "loading" ? "error" : s["ar-en"],
        "en-ar": s["en-ar"] === "loading" ? "error" : s["en-ar"],
      }));
    };

    worker.onmessage = (event: MessageEvent) => {
      const d = event.data as {
        type: string;
        id?: number;
        dir?: Direction;
        pct?: number;
        loadedMB?: number;
        totalMB?: number;
        text?: string;
        message?: string;
      };
      const dir: Direction = d.dir === "en-ar" ? "en-ar" : "ar-en";

      if (d.type === "progress") {
        setStatuses((s) => ({ ...s, [dir]: "loading" }));
        setProgresses((p) => ({ ...p, [dir]: d.pct ?? 0 }));
        setSizes((s) => ({ ...s, [dir]: { loaded: d.loadedMB ?? 0, total: d.totalMB ?? 0 } }));
      } else if (d.type === "ready") {
        setStatuses((s) => ({ ...s, [dir]: "ready" }));
        setProgresses((p) => ({ ...p, [dir]: 100 }));
        try {
          localStorage.setItem(READY_KEY(dir), "1");
        } catch {
          /* ignore */
        }
      } else if (d.type === "result" && d.id !== undefined) {
        pending.current.get(d.id)?.(d.text ?? "");
        pending.current.delete(d.id);
        rejecters.current.delete(d.id);
      } else if (d.type === "error") {
        setError(d.message ?? "خطأ غير معروف");
        if (d.id !== undefined) {
          rejecters.current.get(d.id)?.(new Error(d.message));
          pending.current.delete(d.id);
          rejecters.current.delete(d.id);
        } else {
          setStatuses((s) => ({ ...s, [dir]: "error" }));
        }
      }
    };

    return () => {
      worker.terminate();
      workerRef.current = null;
    };
  }, []);

  const load = useCallback((dir: Direction = "ar-en") => {
    const worker = workerRef.current;
    if (!worker) return;
    setError(null);
    setStatuses((s) => (s[dir] === "loading" || s[dir] === "ready" ? s : { ...s, [dir]: "loading" }));
    // ننتظر حتى يُحدَّد وضع النماذج (مدمجة / تنزيل) قبل بدء التحميل
    (modeRef.current ?? Promise.resolve(false)).then(() => worker.postMessage({ type: "load", dir }));
  }, []);

  const translate = useCallback((text: string, dir: Direction = "ar-en") => {
    const worker = workerRef.current;
    if (!worker) return Promise.reject(new Error("المحرك غير جاهز"));
    const id = ++idRef.current;
    return new Promise<string>((resolve, reject) => {
      pending.current.set(id, resolve);
      rejecters.current.set(id, reject);
      worker.postMessage({ type: "translate", id, text, dir });
    });
  }, []);

  return {
    directions: DIRECTIONS,
    statuses,
    progresses,
    sizes,
    error,
    load,
    translate,
    installedBefore,
    bundled,
    supported,
  };
}
