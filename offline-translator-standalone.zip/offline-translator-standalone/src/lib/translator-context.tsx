import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import { useTranslator } from "./useTranslator";

type TranslatorValue = ReturnType<typeof useTranslator> & { online: boolean };

const Ctx = createContext<TranslatorValue | null>(null);

export function TranslatorProvider({ children }: { children: ReactNode }) {
  const engine = useTranslator();
  const [online, setOnline] = useState(true);

  useEffect(() => {
    setOnline(navigator.onLine);
    const on = () => setOnline(true);
    const off = () => setOnline(false);
    window.addEventListener("online", on);
    window.addEventListener("offline", off);
    return () => {
      window.removeEventListener("online", on);
      window.removeEventListener("offline", off);
    };
  }, []);

  // وضع «التنزيل»: لو المحرك نُزِّل من قبل على هذا الجهاز نشغّله تلقائيًا.
  const { bundled, directions, installedBefore, statuses, load } = engine;
  useEffect(() => {
    if (bundled !== false) return;
    for (const dir of directions) {
      if (installedBefore[dir] && statuses[dir] === "idle") load(dir);
    }
  }, [bundled, directions, installedBefore, statuses, load]);

  return <Ctx.Provider value={{ ...engine, online }}>{children}</Ctx.Provider>;
}

export function useEngine() {
  const value = useContext(Ctx);
  if (!value) throw new Error("useEngine must be used inside TranslatorProvider");
  return value;
}
