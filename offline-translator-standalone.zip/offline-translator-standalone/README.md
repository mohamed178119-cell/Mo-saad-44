# ترجمة أوفلاين (نسخة مستقلة)

تطبيق ترجمة عربي ↔ إنجليزي يعمل بالكامل داخل الجهاز.
مشروع Vite + React ثابت (بدون Lovable وبدون سيرفر) ويتحوّل إلى APK عبر GitHub Actions.

## طريقة البناء
1. أنشئ مستودع GitHub جديد وارفع **محتويات** هذا المجلد (وليس الـ zip نفسه).
2. افتح تبويب **Actions** ← **Build Android APK** ← **Run workflow**.
3. بعد انتهاء البناء نزّل ملف `offline-translator-apk` من أسفل صفحة التشغيل (Artifacts) وفك ضغطه.

## كيف يعمل
- الـ workflow ينزّل نماذج الترجمة (Xenova/opus-mt) من Hugging Face ويضعها في `public/models` فتُدمج داخل الـ APK.
  ← التطبيق يعمل أوفلاين من أول مرة ولا يحتاج تنزيل.
- لو فشل تنزيل النماذج أثناء البناء، يعمل التطبيق بوضع «التنزيل عند أول استخدام» تلقائيًا.
- ملفات تشغيل المحرك (onnxruntime wasm) تُنسخ إلى `public/ort` وتُقرأ محليًا (لا CDN).
- `capacitor.config.ts` لا يحتوي `server.url`، فالتطبيق لا يفتح أي موقع.

## تعديل
- الاسم/المعرّف: `capacitor.config.ts` (appId / appName).
- الواجهة: `src/routes/*` — القاموس المدمج: `src/lib/packs.ts`.
