// ينسخ ملفات تشغيل onnxruntime (wasm) إلى public/ort ليعمل المحرك بدون إنترنت داخل التطبيق.
import { existsSync, mkdirSync, readdirSync, copyFileSync, rmSync } from "node:fs";
import { join } from "node:path";

const candidates = [
  "node_modules/onnxruntime-web/dist",
  "node_modules/@huggingface/transformers/node_modules/onnxruntime-web/dist",
];

const src = candidates.find((p) => existsSync(p));
if (!src) {
  console.error("✗ لم أجد onnxruntime-web داخل node_modules. شغّل npm install أولاً.");
  process.exit(1);
}

const out = "public/ort";
rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

let count = 0;
for (const name of readdirSync(src)) {
  if (!/^ort-wasm.*\.(wasm|mjs)$/.test(name)) continue;
  copyFileSync(join(src, name), join(out, name));
  // نسخة بامتداد .js أيضًا: بعض خوادم الـ WebView لا تعرف MIME الخاص بـ .mjs
  if (name.endsWith(".mjs")) copyFileSync(join(src, name), join(out, name.replace(/\.mjs$/, ".js")));
  count++;
}

if (count === 0) {
  console.error("✗ لم أجد ملفات ort-wasm* في " + src);
  process.exit(1);
}
console.log(`✓ نُسخ ${count} ملف من ${src} إلى ${out}`);
