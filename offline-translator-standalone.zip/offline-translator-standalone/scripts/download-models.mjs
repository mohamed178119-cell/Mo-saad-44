// ينزّل نماذج الترجمة من Hugging Face ويضعها في public/models ليتم دمجها داخل الـ APK.
// لو فشل أي شيء يحذف المجلد بالكامل، فيبقى التطبيق يعمل بوضع «التنزيل عند أول استخدام».
import { createWriteStream, existsSync, mkdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";

const MODELS = ["Xenova/opus-mt-ar-en", "Xenova/opus-mt-en-ar"];

const REQUIRED = [
  "config.json",
  "tokenizer.json",
  "tokenizer_config.json",
  "onnx/encoder_model_quantized.onnx",
  "onnx/decoder_model_merged_quantized.onnx",
];
const OPTIONAL = ["generation_config.json", "special_tokens_map.json"];

const OUT = "public/models";

async function download(repo, file, optional) {
  const url = `https://huggingface.co/${repo}/resolve/main/${file}`;
  const dest = join(OUT, repo, file);
  mkdirSync(dirname(dest), { recursive: true });

  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      const res = await fetch(url, { redirect: "follow" });
      if (res.status === 404 && optional) {
        console.log(`  - (اختياري) غير موجود: ${file}`);
        return false;
      }
      if (!res.ok || !res.body) throw new Error(`HTTP ${res.status}`);
      await pipeline(Readable.fromWeb(res.body), createWriteStream(dest));
      const size = statSync(dest).size;
      if (size === 0) throw new Error("ملف فارغ");
      console.log(`  ✓ ${file} (${(size / 1048576).toFixed(1)} MB)`);
      return true;
    } catch (err) {
      console.log(`  ! محاولة ${attempt} فشلت لـ ${file}: ${err.message}`);
      if (attempt === 4) {
        if (optional) return false;
        throw new Error(`تعذّر تنزيل ${repo}/${file}`);
      }
      await new Promise((r) => setTimeout(r, 2000 * attempt));
    }
  }
  return false;
}

try {
  rmSync(OUT, { recursive: true, force: true });
  for (const repo of MODELS) {
    console.log(`\n⬇ ${repo}`);
    for (const f of REQUIRED) await download(repo, f, false);
    for (const f of OPTIONAL) await download(repo, f, true);
  }
  writeFileSync(
    join(OUT, "manifest.json"),
    JSON.stringify({ models: MODELS, createdAt: new Date().toISOString() }, null, 2),
  );
  console.log("\n✓ تم تجهيز النماذج داخل public/models");
} catch (err) {
  console.error("\n✗ فشل تجهيز النماذج:", err.message);
  if (existsSync(OUT)) rmSync(OUT, { recursive: true, force: true });
  process.exit(1);
}
