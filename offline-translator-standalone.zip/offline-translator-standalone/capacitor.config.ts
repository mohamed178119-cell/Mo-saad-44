import type { CapacitorConfig } from "@capacitor/cli";

// التطبيق كله (الواجهة + المحرك + النماذج) داخل الـ APK — لا يوجد server.url ولا يفتح أي موقع.
const config: CapacitorConfig = {
  appId: "com.mohamedsaad.offlinetranslator",
  appName: "ترجمة أوفلاين",
  webDir: "dist",
  android: {
    allowMixedContent: false,
    adjustMarginsForEdgeToEdge: "auto",
  } as CapacitorConfig["android"],
};

export default config;
